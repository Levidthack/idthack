var StellarSdk = require('stellar-sdk');
var server = new StellarSdk.Server('https://horizon-testnet.stellar.org');

//the JS SDK uses promises for most actions, such as retrieving an account
server.loadAccount('GC4YJRCMD65626HEXMYSA3UTXWLWLNG7SF4XSQZ6346HLNAB2EH7WTKN').then(function(account) {
  console.log('Balances for account: ' + 'GC4YJRCMD65626HEXMYSA3UTXWLWLNG7SF4XSQZ6346HLNAB2EH7WTKN');
  account.balances.forEach(function(balance) {
    console.log('Type:', balance.asset_type, ', Balance:', balance.balance);
  });
});
