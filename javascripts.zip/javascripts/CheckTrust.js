var StellarSdk = require('stellar-sdk');
StellarSdk.Network.useTestNetwork();
var server = new StellarSdk.Server('https://horizon-testnet.stellar.org');

var astroDollarCode = 'CRD';
var astroDollarIssuer =
  'GC4YJRCMD65626HEXMYSA3UTXWLWLNG7SF4XSQZ6346HLNAB2EH7WTKN';

var accountId = 'GCZ2MXFXT44Z3OMXF4RZBS4BEWOOQR4EFVSJMNIR3JZ5GTRI7Y2TJLM6';
server.loadAccount(accountId).then(function(account) {
  var trusted = account.balances.some(function(balance) {
    return balance.asset_code === astroDollarCode &&
           balance.asset_issuer === astroDollarIssuer;
  });

  console.log(trusted ? 'Trusted :)' : 'Not trusted :(');
});
