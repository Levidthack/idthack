var generatePair = function() {
  var StellarSdk = require('stellar-sdk');

  var pair = StellarSdk.Keypair.random();

  var seed = pair.secret();
  console.log("seed: " + seed);

  var key = pair.publicKey();
  console.log("public: " + key);
}

generatePair();
